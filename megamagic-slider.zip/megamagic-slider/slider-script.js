// clients slider
let clientsSlider = $('.clients-slider');
clientsSlider.owlCarousel({
	items: 1,
	loop: true,
	autoplay: true,
	autoplaySpeed: 4000,
	navSpeed: 1000,
	smartSpeed: 1000,
	autoplayTimeout: 4000,
	autoplayHoverPause: true,
	dots: false,
	margin: 15,
	nav: true,
	navText: ["<i class='fas fa-chevron-left'></i>", "<i class='fas fa-chevron-right'></i>"],
	responsive: {
		0: {
			items: 1
		},
		768: {
			items: 2,
			stagePadding: 60
		},
		992: {
			items: 3
		},
		1200: {
			items: 3
		},
		1365: {
			items: 4,
			stagePadding: 0
		}
	}

})